void function(int a, int b)
{
   int array[5];
}

main()
{
   function(1,2);

   printf("This is where the return address points");
}
