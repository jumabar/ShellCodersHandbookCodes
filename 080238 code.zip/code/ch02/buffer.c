#include <stdio.h>
#include <string.h>

int main () 
{
    int array[5] = {1, 2, 3, 4, 5};
    
    printf("%d\n", array[5] );
}
