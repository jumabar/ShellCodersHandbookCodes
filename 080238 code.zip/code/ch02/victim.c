// victim.c
int main(int argc,char *argv[])
{
   char little_array[512];

   if (argc > 1) 
      strcpy(little_array,argv[1]);
}
